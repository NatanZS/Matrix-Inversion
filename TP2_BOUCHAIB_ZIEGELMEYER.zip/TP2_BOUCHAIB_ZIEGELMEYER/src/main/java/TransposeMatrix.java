import java.io.IOException;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author Natan Ziegelmeyer & Hichem Bouchaib
 */

public class TransposeMatrix {

    public static class TransposeMapper extends Mapper<LongWritable, Text, LongWritable, Text> {
        @Override
        protected void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
            long col = 0;
            long idx = key.get();
            for (String value : values.toString().split(",")) {
                context.write(new LongWritable(col), new Text(idx + "\t" + value));
                ++col;
            }
        }
    }

    public static class TransposeReducer extends Reducer<LongWritable, Text, Text, NullWritable> {
        @Override
        protected void reduce(LongWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            TreeMap<Long, String> treeMap = new TreeMap<Long, String>();
            for (Text value : values) {
                String[] parts = value.toString().split("\t");
                treeMap.put(Long.valueOf(parts[0]), parts[1]);
            }
            String row = StringUtils.join(treeMap.values(), ',');
            context.write(new Text(row), NullWritable.get());
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration config = new Configuration();
        Job job = Job.getInstance(config, "transpose matrix");
        job.setJarByClass(TransposeMatrix.class);
        job.setMapperClass(TransposeMapper.class);
        job.setReducerClass(TransposeReducer.class);
        job.setOutputKeyClass(LongWritable.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}